const background = chrome.runtime.connect();

console.log('Extension running on Airbnb.');